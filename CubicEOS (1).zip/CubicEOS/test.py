# -*- coding: utf-8 -*-
"""
Created on Tue Aug 25 14:29:00 2015

@author: Ashwin
"""

import perrysdata
import eosClass

methane = perrysdata.Compound("Methane")
methane = eosClass.EOS(methane)
